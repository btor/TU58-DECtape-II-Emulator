/*-------------------------------------------------------------------------
   Serial library functions for DOS

   Written by -  Bela Torok / www.torok.info & www.belatorok.com (February 2006)

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public
   License as published by the Free Software Foundation; either
   version 2 of the License (http://www.gnu.org/licenses/gpl.txt).

   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   In other words, you are welcome to use, share and improve this program.
   You are forbidden to forbid anyone else to use, share and improve
   what you give them.   Help stamp out software-hoarding!
-------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <time.h>
#include <malloc.h>
#include <dos.h>
#include <string.h>

#include "irq.h"
#include "serial.h"

#define COM1 0
#define COM2 1
#define COM3 2
#define COM4 3

#define BAUD_300    0x0180
#define BAUD_600    0x00C0
#define BAUD_1200   0x0060
#define BAUD_2400   0x0030
#define BAUD_4800   0x0018
#define BAUD_9600   0x000C
#define BAUD_19200  0x0006
#define BAUD_38400  0x0003
#define BAUD_57600  0x0002
#define BAUD_115200 0x0001

// Line Control Register
#define W_SIZE_5    0x0
#define W_SIZE_6    0x01
#define W_SIZE_7    0x02
#define W_SIZE_8    0x03
#define STOP_BIT_1  0x0
#define STOP_BIT_2  0x04
#define PARITY_EVEN 0x18
#define PARITY_ODD  0x08
#define BREAK_FLAG  0x40

#define DTR         1
#define RTS         2
#define OUT1        4
#define OUT2        8

// UART (16550) Register definitions
#define IER   1     // Interrupt Enable Register
#define IIR   2     // Interrupt Ident. Register (read only)
#define FCR   2     // FIFO Control Register (write only)
#define LCR   3     // Line Control Register
#define MCR   4     // Modem Control Register
#define LSR   5     // Line Status Register
#define MSR   6     // Modem Status Register
#define SCR   7     // Scratch Register

#define IIR_ERBFI   1       // Enable Received Data Available Interrupt
#define IIR_ETBEI   2       // Enable Transmitter Holding Register Empty Interrupt
#define IIR_ELSI    4       // Enable Line Status Interrupt
#define IIR_EDSSI   8       // Enable Modem Status Interrupt


#define LSR_DATA_READY      1
#define LSR_OVERRUN_ERROR   2
#define LSR_PARITY_ERROR    4
#define LSR_FRAMING_ERROR   8
#define LSR_BREAK_INTERRUPT 0x10
#define LSR_TRANSMITTER_HOLDING_REGISTER_EMPTY  0x20
#define LSR_TRANSMITTER_EMPTY                   0x40
#define LSR_ERROR_IN_RECEIVED_FIFO              0x80

#define DATA_FORMAT 3
#define BAUD_LSB    0
#define BAUD_MSB    1

#define NOPARITY    0
#define EVENPARITY  0x18
#define ODDPARITY   0x08

#define ONESTOPBIT 0
#define TWOSTOPBIT 4

#define RX_THRESHOLD 16
#define NUMBER_OF_COM_PORTS 4


#define FC_NOPROTOCOL   0x00
#define FC_DTRDSR       0x01
#define FC_RTSCTS       0x02
#define FC_XONXOFF      0x04


/* GLOBAL VARIABLES */
int UartAddress[NUMBER_OF_COM_PORTS];
char *rxbuf[NUMBER_OF_COM_PORTS];
char break_received[NUMBER_OF_COM_PORTS];
int rxbuf_size[NUMBER_OF_COM_PORTS];
int rxin[NUMBER_OF_COM_PORTS], rxout[NUMBER_OF_COM_PORTS], rxcnt[NUMBER_OF_COM_PORTS];
int irq[NUMBER_OF_COM_PORTS] = {4, 3, 4, 3};    // Default IRQs
int Com_Mode[NUMBER_OF_COM_PORTS];
unsigned char Com_MSR[NUMBER_OF_COM_PORTS];
int protocol_type = FC_NOPROTOCOL;
int rx_timeout, tx_timeout;
int Com_Port_Number[NUMBER_OF_COM_PORTS] = {0, 1, 2, 3};

void (interrupt far *oldhandler[NUMBER_OF_COM_PORTS])();

void register_setbit(int ComPort, int offset, int mask)
{
    outp(UartAddress[ComPort] + offset, inp(UartAddress[ComPort] + offset) | mask);
}

void register_clearbit(int ComPort, int offset, int mask)
{
    outp(UartAddress[ComPort] + offset, inp(UartAddress[ComPort] + offset) & ~mask);
}

void Com_Setbaud(int ComPort, int baud)
{
    outp(UartAddress[ComPort] + LCR, (inp(UartAddress[ComPort] + LCR) | 0x80));
    outp(UartAddress[ComPort] + BAUD_LSB, baud & 0x00ff);
    outp(UartAddress[ComPort] + BAUD_MSB, baud >> 8);
    outp(UartAddress[ComPort] + LCR, (inp(UartAddress[ComPort] + LCR) & 0x7f));
}

void GetCharacterFromUart(int ComPort)
{
    int lsr, IsBreak;
    char RxChar;

    while(1) {
        lsr = inp(UartAddress[ComPort] + LSR) ;

        IsBreak = 0;

        if((lsr & (LSR_FRAMING_ERROR + LSR_BREAK_INTERRUPT + LSR_ERROR_IN_RECEIVED_FIFO)) != 0) {
            break_received[ComPort] = 1;
            IsBreak = 1;
        }

        if((lsr & LSR_DATA_READY)== 0) break; // exit
       
        RxChar = inp(UartAddress[ComPort]);

        if(IsBreak == 0) { // if Break do not store RxChar in Buffer;
            rxbuf[ComPort][rxin[ComPort]] = RxChar;
            rxin[ComPort]++;
            rxcnt[ComPort]++;
            if(rxin[ComPort] == rxbuf_size[ComPort]) rxin[ComPort] = 0;

            if(rxcnt[ComPort] > (rxbuf_size[ComPort] - (rxbuf_size[ComPort] >> 2))) {  // threshold = 0.75 * rxbuf_size
                if(protocol_type == FC_DTRDSR) register_clearbit(ComPort, MCR, DTR);    // Disable RX
                if(protocol_type == FC_RTSCTS) register_clearbit(ComPort, MCR, RTS);    // Disable RX
            }
        }
    } 
}

void SerialClearRxBuffer(int *pComPort)
{
    int ComPort;

    ComPort = *pComPort;

    rxin[ComPort]  = 0;
    rxout[ComPort] = 0;
    rxcnt[ComPort] = 0;

    break_received[ComPort] = 0;
}

void IsrHandler(int PortNumber)   // Com1 is 0, Com2 is 1, etc
{
    int iir, lsr;

    while(1) {
        iir = inp(UartAddress[PortNumber] + IIR);

        if(iir & 1) break;  // pending interrupts?

        if(iir == 6) {  // receiver overrun

            // Overrun Error or Parity Error 
            // or Framing Error or Break Interrupt
            GetCharacterFromUart(PortNumber);
        }

        if(iir == 4 ) { // character received?
            GetCharacterFromUart(PortNumber);
        }

        if(iir == 0xc) { // character timeout indication
            inp(UartAddress[PortNumber]); // read Rx buffer
        }

        if(iir == 2) {
            // transmit register empty
            ;
        }

        if(iir == 0) { // modem status
            // source: CTS or DSR or RI or DCD
            Com_MSR[PortNumber] = inp(UartAddress[PortNumber] + MSR);    
        }
      
    }

    _end_interrupt(irq[PortNumber]);
}

void interrupt far Com1Isr(void)
{
    IsrHandler(COM1);  
}

void interrupt far Com2Isr(void)
{
    IsrHandler(COM2);  
}

void interrupt far Com3Isr(void)
{
    IsrHandler(COM3);  
}

void interrupt far Com4Isr(void)
{
    IsrHandler(COM4);  
}

/*******************/
/* Initialize COMx */
/*******************/
void Com_Init(int ComPort)
{
    int far *port_addr;
  
    port_addr = (int far *) 0x400L; // BIOS prot address table

    if( ComPort < 0 | ComPort >= NUMBER_OF_COM_PORTS){
        printf("Illegal Com port number - aborting\n");
        exit(1);
    }

    if(port_addr[ComPort] == 0){
        printf("Non existing port !");
        exit(1);
    }

    UartAddress[ComPort] = port_addr[ComPort];    /* get port address from BIOS area */

}

/*******************/
/* Initialize COMx */
/*******************/
void Com_Open_Poll(int ComPort, int Lcr, int baud, int size_rxbuf, int rxtimeout, int txtimeout)
{
    rx_timeout = rxtimeout;
    tx_timeout = txtimeout;

    rxbuf_size[ComPort] = size_rxbuf;
    rxbuf[ComPort] = calloc(rxbuf_size[ComPort], 1);

//    ClearRxBuffer(ComPort);

    Com_Init(ComPort);

    Com_Mode[ComPort] = 0; // polling

    /* Set communication parameters, length, parity, stop bits */
    outp(UartAddress[ComPort] + LCR, Lcr);

    /* Set baudrate */
    Com_Setbaud(ComPort, baud);

    /* Activate & Init FIFO (if chip is 16550) */
    outp(UartAddress[ComPort] + FCR, 0x00); // disable FIFO
//  outp(UartAddress[ComPort] + FCR, 0x07); // reset RX and TX FIFO, Trigger level: 1 Bytes
//  outp(UartAddress[ComPort] + FCR, 0xC7); // reset RX and TX FIFO, Trigger level: 14 Bytes
//  outp(UartAddress[ComPort] + FCR, 0x87); // reset RX and TX FIFO, Trigger level: 8 Bytes

    /* Clear UART Rx buffer (if chip is 8250) */
    inp(UartAddress[ComPort]);
    inp(UartAddress[ComPort]);

    /* Set modem control */
    register_setbit(ComPort, MCR, RTS | DTR);    // Enable RX
}

void Com_Open_Int(int ComPort, int Lcr, int baud, int size_rxbuf, int rxtimeout, int txtimeout)
{
    oldhandler[ComPort] = _dos_getvect(_get_interrupt_vector(irq[ComPort]));

    Com_Init(ComPort);

    switch (ComPort) {
    case COM1:
        _dos_setvect(_get_interrupt_vector(irq[COM1]), Com1Isr);
        break;
    case COM2:
        _dos_setvect(_get_interrupt_vector(irq[COM2]), Com2Isr);
        break;
    case COM3:
        _dos_setvect(_get_interrupt_vector(irq[COM3]), Com3Isr);
        break;
    case COM4:
        _dos_setvect(_get_interrupt_vector(irq[COM4]), Com4Isr);
        break;
    default:
        printf("Illegal Com%d port number - aborting\n", ComPort);
        exit(1);
    }

    Com_Open_Poll(ComPort, Lcr, baud, size_rxbuf, rxtimeout, txtimeout);

    Com_Mode[ComPort] = 1; // interrupt driven

    /* OUT2 enables interrupts */
    register_setbit(ComPort, MCR, OUT2);

    _enable_pic_interrupt(irq[ComPort]);

    /* Write to Interrupt enable Register */
    outp(UartAddress[ComPort] + IER, IIR_ERBFI + IIR_ELSI);  // enable interrupts on receive and line status
}

void SerialClose(int *pComPort)
{
    int ComPort;

    ComPort = *pComPort;

    // does not restore previous state !
    if(protocol_type != FC_NOPROTOCOL) register_clearbit(ComPort, MCR, RTS | DTR);  // Disable RX
    register_clearbit(ComPort, MCR, OUT2);
    outp(UartAddress[ComPort] + IER, 0);  // disable interrupts
    if(Com_Mode[ComPort] == 1) {
        _disable_pic_interrupt(irq[ComPort]);
        _dos_setvect(_get_interrupt_vector(irq[ComPort]), oldhandler[ComPort]);
    }
    free(rxbuf[ComPort]);
}

int SerialNumCharsInRxBuffer(int *pComPort)
{
    int c;
    int ComPort;

    ComPort = *pComPort;


    if(Com_Mode[ComPort] == 0) {
        // polling mode
        GetCharacterFromUart(ComPort);  // Get character if available
    }

    if(rxcnt[ComPort] < (rxbuf_size[ComPort] >> 1)) {  // threshold = 0.5 * rxbuf_size
        if(protocol_type == FC_DTRDSR) register_setbit(ComPort, MCR, DTR); // Enable RX
        if(protocol_type == FC_RTSCTS) register_setbit(ComPort, MCR, RTS); // Enable RX
    }

    return rxcnt[ComPort];
}

/**************************/
/* Read a Byte  from COMx */
/**************************/
int SerialGetc(int *pComPort)
{
    clock_t counter;
    int inchar, timer;
    int ComPort;

    ComPort = *pComPort;

    if(break_received[ComPort] != 0) { // BREAKreceived!
//        ClearRxBuffer(*pComPort);
        break_received[ComPort] = 0;
        return BREAK;
    }

    counter = clock() + rx_timeout; // after rx_timeout msec generate time-out
    while(1) {
        if(SerialNumCharsInRxBuffer(pComPort) != 0) break;
        if(clock() > counter) return TIMEOUT;
    } 

    _disable(); // disable interrupts

    inchar = rxbuf[ComPort][rxout[ComPort]];
    rxout[ComPort]++;
    if(rxout[ComPort] == rxbuf_size[ComPort]) rxout[ComPort] = 0;
    rxcnt[ComPort]--;

    _enable(); // enable interrupts

    return (inchar & 0xff);
}

/*************************/
/* Output a Byte to COMx */
/*************************/
int SerialPutc(int *pComPort, char out_char)
{
    clock_t counter;
    int timer;
    int ComPort;

    ComPort = *pComPort;

    // hardware protocol with timeout should be added !!

    counter = clock() + tx_timeout; // after tx_timeout msec generate time-out

    while(1) {
        if((inp(UartAddress[ComPort] + LSR) & LSR_TRANSMITTER_HOLDING_REGISTER_EMPTY) != 0) break;
        if(clock() > counter) return TIMEOUT;
    } 

    outp(UartAddress[ComPort], out_char);

    return 0;
}

/***************************/
/* Output a string to COMx */
/***************************/
void SerialPuts(int *pComPort, char *str)
{
    int length, i, status;
    int ComPort;

    ComPort = *pComPort;

    length = strlen(str);

    for(i = 0; i < length; i++) {
        status = SerialPutc(pComPort, str[i]);
        if(status == TIMEOUT) return; 
    }

    SerialPutc(pComPort, '\n');
}


char* SerialGets(int *pComPort)
{
    static char rxstring[258];
    int c;
    int pos = 0;

    if(pComPort == NULL) return "SerialGetsError";

    while(pos <= 255) {
        c = SerialGetc(pComPort);
        if(c == -1) {
            return "SerialGetsError";
        }
        if(c == '\n') break;
        if(c != '\r') rxstring[pos++] = (char) c;   // discard carriage return
    }
    rxstring[pos] = 0;

    return  rxstring;
}

void SerialDisableRx(int *pComPort)
{
    clock_t goal;
    int ComPort;

    ComPort = *pComPort;

    if(protocol_type == FC_DTRDSR) register_clearbit(ComPort, MCR, DTR);    // Disable RX
    if(protocol_type == FC_RTSCTS) register_clearbit(ComPort, MCR, RTS);    // Disable RX

    goal = clock() + 100;  // wait 100 ms to complete pending Rx
    while ( goal > clock() );
}

int* SerialInit(char *ComPortName, unsigned long BaudRate, int ByteSize, int StopBit, char ParityChar, char ProtocolChar, int RxTimeOut, int TxTimeOut, int RxBufSize, int TxBufSize) 
{
    /* The following parameter is not implemented: TxBufSize */

    char Name[40];

    int i, BaudDiv, LcrReg, ComPort, *pComPort, Irq = 0;

    pComPort = 0; // error opening com port

    switch(ProtocolChar) 
    {
    case 'D':   // DTR/DSR
    case 'd':
        protocol_type = FC_DTRDSR;
        break;
    case 'R':   // RTS/CTS
    case 'r':
        protocol_type = FC_RTSCTS;
        break;
    case 'X':   // XON/XOFF
    case 'x':
        protocol_type = FC_XONXOFF;
        break;
    case 'N':   // NOPROTOCOL
    case 'n':
    default:
        protocol_type = FC_NOPROTOCOL;
        break;
    }

    switch(BaudRate) 
    {
    case 110:
    case 300:
    case 600:
    case 1200:
    case 2400:
    case 4800:
    case 9600:
    case 19200:
    case 38400:
    case 57600:
    case 115200:
        BaudDiv = (int) (115200L / BaudRate);
        break;
    default:
        return pComPort;
        break;
    }

    switch(ByteSize) 
    {
    case 8:
        LcrReg = W_SIZE_8;
        break;
    case 7:
        LcrReg = W_SIZE_7;
        break;
    case 6:
        LcrReg = W_SIZE_6;
        break;
    case 5:
        LcrReg = W_SIZE_5;
        break;
    default:
        return pComPort;
        break;
    }

    switch(StopBit) 
    {
    case 1:
        LcrReg |= ONESTOPBIT;
        break;
    case 2:
        LcrReg |= TWOSTOPBIT;
        break;
    default:
        return pComPort;
        break;
    }


    switch(ParityChar) 
    {
    case 'N':
    case 'n':
        LcrReg |= NOPARITY;
        break;
    case 'E':
    case 'e':
        LcrReg |= EVENPARITY;
        break;
    case 'O':
    case 'o':
        LcrReg |= ODDPARITY;
        break;
    default:
        return pComPort;
        break;
    }

    for(i = 0; i <= strlen(ComPortName); i++) 
    {
        if(isupper((int) ComPortName[i]) != 0) {
            Name[i] = (char) tolower((int) ComPortName[i]);
        } else {
            Name[i] = ComPortName[i];
        }
    }

    if(strncmp(Name, "com", 3) != 0) return pComPort;   // error

    ComPort = atoi(&Name[3]);

    // Support for com ports with non-standard IRQs
    //
    // Portnames: com1, ..., com4 are using the default IRQs
    // 
    // Portnames with non-standard IRQs can be calculatted as
    // "com" + 10 * IRQ + PortNumber, e.g., for Com3 with IRQ7 use port name: Com73


    Irq = ComPort / 10;

    // do not use following IRQs
    if(Irq > 15)    return pComPort;    // Illegal IRQ
    if(Irq == 1)    return pComPort;    // reserved for PC Keyboard
    if(Irq == 2)    return pComPort;    // reserved for secondary PIC
    if(Irq == 8)    return pComPort;    // reserved for secondary Real time clock

    ComPort = ComPort % 10;    

    ComPort--;

    if(Irq != 0) irq[ComPort] = Irq;

    if(ComPort < 0 || ComPort > 3) return pComPort; // Illegal ComPortName

    Com_Open_Int(ComPort, LcrReg, BaudDiv, RxBufSize, RxTimeOut, TxTimeOut);

    return &Com_Port_Number[ComPort];
}


// main() was implemented for testing!
/*
int main(int argc, char *argv[])
{
    int argn, c = 0, inch = 0, com_pos = 0;
    char command[128];
    int ComPort = COM1;

    SerialInit("Com1", 38400, 8, ONESTOPBIT, NOPARITY, FC_NOPROTOCOL, 1000, 1000, 256, 256); 

    do {
        if(kbhit()) {
            c = getch();
            SerialPutc(ComPort, c);
        }

        while( SerialNumCharsInRxBuffer(ComPort) != 0 ) {
            inch = SerialGetc(ComPort);
            if(inch == '\n' || inch == '\r') inch = 0;
            command[com_pos++] = inch;
            if(com_pos > 63) com_pos = 0; // buffer overflow
            if(inch == 0) break;
        }

        if(com_pos > 0 && inch == 0) {   // command ready
        // execute command
        printf("Command= %s\n\n", command);
        inch = 0xff;
        com_pos = 0;
        }
    } while(c!=27);

    SerialClose(ComPort);

    return 0;
}
*/


