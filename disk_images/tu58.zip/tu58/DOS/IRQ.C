#include <stdlib.h>
#include <stdio.h>
#include <conio.h>

#include <dos.h>
#include "irq.h"

#define PIC1 0x20
#define PIC2 0xA0

/*-------------------------------------------------------------------------
   irq.c - DOS - IRQ related routines

   Written By -  Bela Torok / bela.torok@kssg.ch (November 2000)

   Please send improvements to the author!

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the
   Free Software Foundation; either version 2, or (at your option) any
   later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

   In other words, you are welcome to use, share and improve this program.
   You are forbidden to forbid anyone else to use, share and improve
   what you give them.   Help stamp out software-hoarding!
-------------------------------------------------------------------------*/



int _get_pic_address(int irq)
{
  /* Calculate PIC Addr */
  int pic_address;

  if (irq >= 2 && irq <= 7) pic_address = PIC1;

  if (irq >= 8 && irq <= 15) pic_address = PIC2;

  if (irq < 2 || irq > 15) pic_address = -1; // error

  return pic_address;
}

int _get_interrupt_mask(int irq)
{
  int picmask;  /* PIC's Mask */
  picmask = 1;

  /* Calculate Interrupt Vector, PIC Addr & Mask. */
  if (irq >= 2 && irq <= 7) {
    picmask = picmask << irq;
  }
  if (irq >= 8 && irq <= 15) {
    picmask = picmask << (irq - 8);
  }
  if (irq < 2 || irq > 15) {
    // irq Out of Range
    picmask = -1;
  }

  return picmask;
}

void _enable_pic_interrupt(int irq)
{
  int pic_address, pic_mask;

  pic_address = _get_pic_address(irq);
  pic_mask    = _get_interrupt_mask(irq);

  // set new mask
  outp(pic_address + 1, inp(pic_address + 1) & (0xff - pic_mask)); /* Un-Mask Pic */
}

void _disable_pic_interrupt(int irq)
{
  int pic_address, pic_mask;

  pic_address = _get_pic_address(irq);
  pic_mask    = _get_interrupt_mask(irq);

  outp(pic_address + 1, inp(pic_address + 1) | pic_mask); /* Mask Pic */
}

void _end_interrupt(int irq)
{
  outp(_get_pic_address(irq), 0x20); /* End of Interrupt (EOI) */
}

int _get_interrupt_vector(int irq)
{
  int vector;

  /* Calculate Interrupt Vector, PIC Addr & Mask. */

  if (irq >= 2 && irq <= 7) vector = irq + 0x08;

  if (irq >= 8 && irq <= 15) vector = irq + 0x68;

  if (irq < 2 || irq > 15)  vector = -1; // error

  return vector;
}
