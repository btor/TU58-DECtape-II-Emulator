#define TIMEOUT -1
#define BREAK -16


int* SerialInit(char*, unsigned long, int, int, char, char, int, int, int, int); 

void SerialClearRxBuffer(int*);

int SerialGetc(int*);

int SerialPutc(int*, char);

char* SerialGets(int*);

void SerialPuts(int*, char*);

int SerialGetModemStatus(int*, int);

void SerialClearRxBuffer(int*);

int SerialNumCharsInRxBuffer(int*);

void SerialDisableRx(int*);

void SerialClose(int*); 
