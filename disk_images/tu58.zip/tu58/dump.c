/*******************************************************

"name"               "stands for"              "creation date"

dump            dump contents memory to file       1989

DESCRIPTION:
   standard dump format, variable length buffer.
   display hex values of bytes on left and any
   printable asci values to right side of page.
   Use fp = stdout for screen dump

ENTRY POINT:
dump(fp,s,len,line)
   file * fp;             level 2 file pointer 
   char *s;               source data to display 
   unsigned len,line;     # characters and starting line # 

RETURN VALUE:
   none
EXTERNAL REFERENCES:
   none
SIDE EFFECTS:
   writes text to a level 2 file (may be console, stdout)
NOTES:
   caller must provide file handle, stdout, if to be directed
   to the console.  Call incrementally with a delay if display 
   a large block of data.  line is a separate parameter to
   fascilitate this and allow ranges of address to be displayed
   see also dump_sec()

MODIFICATION HISTORY:
11/12/02 linux port, remove strupr by using sprintf(,%02X) not %02x
07/16/93 cast *s to unsigned when do dump, 0x8F is coming out
         0xff in vaxm??
07/15/91 appears to have had off by one error for binary
         display when i == len, should pad.  Were getting
         one garbage character

07/12/91 add include of ctype.h for isprint()
02/13/91 see comment ready for character data fields
         surpress this assignment making full line
         shorter by 1 char so doesn't overflow in dumpit
         change str arg to unsigned char, think it
         was sign extending
1989   willy    adapated from pascal work on VT180
                see scrdump.inc
    
********************************************************/
#include <stdio.h>
#include <string.h>
#include <ctype.h>

void dump(	FILE * fp,			// level 2 file pointer
			unsigned char *s,	// source data to display
			int len,		// # characters
			int line)		// starting line #
{   
    int i;
    char buf[80],*bin,*ch,*bar;
    while (len > 0)
    {
        sprintf(buf,"%04x:",line);
        bin = buf + strlen(buf);  /* next available location */
        bar = bin + 52;  /* set up to overwrite bin string terination */
        ch = bar +1;
/*        *(ch++) = ' ';    ready for character data fields */

        for (i=0; i < 16; i++)
        {
            if (i > 0 && i % 4 == 0)  /* group binary in blocks of 4 */
                sprintf(bin++," ");

            if (i >= len)  /* pad last line with blanks */
            {
                sprintf(bin,"   ");
                bin +=3;
                *(ch++) = ' ';
            }
            else
            {
                sprintf(bin," %02X",(unsigned)*s);
                bin +=3;
                if (isprint(*s)) *ch = *s;
                else *ch = '.';  /* not printable */
                ch++;
                s++;
            }
        }

        /* be a little careful len is unsigned so it won't go negative */
        if (len > 16) len -=16;
        else len = 0;

        line += 16;
        *ch = 0;     /* terminate string after ascii data */
        *(bar--) = '|';   /* add bar */
        *bar = ' ';   /* should overwrite binary string terminator */
        fprintf(fp,"%s\n",buf);
    }
}


