/* TU58 DECtape II emulator 

   This is a modified, operating system independent version of the TU58 emulator of William T. Kranz.
   This port was developed using his tu58.c version 1.04 files with his permission.
   Most of the code is his work, see changes in the history.

   Written by: William T. Kranz (Version 1.0x) & Bela Torok (Version 2.0)

   Contact via: 

   William T. Kranz, http://www.fpns.net/willy/contact.htm
   (Core components & version 1.x-specific code, MRSP)

   Bela Torok, http://www.torok.info & http://www.belatorok.com
   (Multi OS port and serial library for Windows and DOS)

   Version 1.0 for DOS is still available from http://www.fpns.net/willy/pdp11/rt11arc.exe

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public
   License as published by the Free Software Foundation version 2 of the 
   License (http://www.gnu.org/licenses/gpl.txt).

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   General Public License for more details.
-------------------------------------------------------------------------*/

/*----------- Version 1.0x History ------------
12/93 Version 1.00 release on Compuserve
03/94 Version 1.01 implement -i command line option
04/94 Version 1.02 conditionally add some rainbow specific code
          also add -p command line option and create RT11 style
          directory structure when create a new image via -c 
02/00 Version 1.03 work on boot and BREAK detection (see LCOM define)
          serial com routines now recognize 16550 uart fifo
05/05 Version 1.04 has not been formally released by Will's Works
          It included adding conditionals MAIN and NORESYNC
          for work on DOS pdpmon.exe and
08/04 an attempt to handle MRSP (modified RSP used in RSX)
          Warning this is not fully tested or verified
*/

/*----------- Version 2.00 History ------------
Jan/12/2006 First version of the operating system independent code,
			Currenly only Windows & DOS is supported.
			DOS specific code was removed, e.g., polled mode serial I/O, delays in clock ticks, etcCommand received -> 
			Functions rsp_get_packet() and rsp_snd_packet() were rewrtitten, CalculateChecksum() added.
			The functions rsp_power_up() and rsp_resync() were removed, rsp_power_up() specific functionality 
			was added to main(), parts of main() were rewritten.
			Function calls to tdelay() were replaced by WaitMilliseconds(). 
			Started to rename variable names according to the terminology used in the TU58 DECtape II User's Guide.
			The TU58 DECtape II User's Guide can be downloaded from the following URL:
			http://www.bitsavers.org/pdf/dec/dectape/EK-0TU58-UG-001_TU58ug.pdf
			The tu58.ini file is not supported, tu58.ini-specific settings are migrated to the command line.
			According to Will's information MRSP is inmature, it is however not needed for RT11. 
			MRSP-support is a 1:1 implementation of Will's code.
			Most of the version 1.x specific history was removed.
			#ifdef _DOS, #ifdef _WIN32 and #ifdef _WIN64 were added to support for port-specific compilation.
			Variable ctl.status was moved to global variable MrspEnable.
			Bela Torok - www.torok.info
			
Feb/02/2006 Win32 and DOS subdirectories were created for prort-specific code. 
			Win32 versions of serial.c and serial.h were moved to the Win32 subdirectory.
			typedef unsigned long DWORD was added to tu58.c, BaudRate is now defined as DWORD.
			Global variable HANDLE hTu58Port was definde for the Win32-port.
			Checksum calculation was changed to be compatible both with little endian and big endian format. 
			Multibyte variables are stored by Intel and many other CPUs using the little endian format (lowest byte
			in the lowest memory address), other CPUs, e.g., SUN Spark, Motorola 680x, 680x0, PowerPC, 
			Freescale microcontrollers, etc. are using the big endian format (highest byte at the lowest address). 
			Bela Torok - www.torok.info

Feb/06/2006 Function WaitMilliseconds() was added. Compiler specific code for other ports can be added 
			to it. The compiler specific wait() function is optional if not added slow device emulation is disabled.
			Function rt11_initialize() was deleted, CreateRawImageFile() added.
			Pressing <ESCAPE> also terminates the program.
			Bela Torok - www.torok.info

Feb/08/2006 DOS port implemented but probably not functional.
			DOS-specific files are in the DOS subdirectory. Files can be compiled without errors with
			the OpenWatcom compiler. Use the following commands to generate the DOS executable:
			cd DOS
			make 
			"make" is a batch file (make.bat).
			The DOS executable is generated in the DOS subdirectory.
			Bela Torok - www.torok.info

Feb/05/2011 MRSP support and modifications for XXDP compatibility.
			Parts of the MRSP code was merged form Don North's TU58 emulator:
			http://www.slowdeath.com/AK6DN/PDP-11/TU58/tu58em/index.html
			Other additions are the result of the reverse engineering of the XXDP ZTUUF0 TU58 
			test: http://bitsavers.informatik.uni-stuttgart.de/pdf/dec/pdp11/xxdp/fiche_200dpi/0150_CZTUUF0_TU58.pdf
		 
			The emulator pass the test programs XXDPV25 -> ZTUUF0.bin, XXDPV22 -> ZTUUD0.bin.
			The RT11 operating system does not use the MRSP protocol!
			MRSP is timing critical, does not work reliably:
			- with USB to Serial converters
			- with the E11 emulator
			- if multiple tasks are running on the Windows host

			The limitations above are not relevant for RT11 operating system, it does not use the MRSP protocol.

*/

/*
To do list:
			1. I have never had time to finish the DOS serial library, there is a lot of room for improvements.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <fcntl.h>
#include <sys\types.h>
#include <sys\stat.h>   /* for stat */
#include <io.h>
#include <time.h>
#include "tu58.h"

/////// DOS specific include files
#ifdef _DOS
#include <dos.h>
#include <conio.h>
#include <string.h>
#include "dos\serial.h"
#endif
/////// end of DOS specific include files

/////// Windows specific include files
#ifdef _WIN32
#define MS_WINDOWS
#endif
#ifdef _WIN64
#define MS_WINDOWS
#endif

#ifdef MS_WINDOWS

#if _MSC_VER > 1000
#include <windows.h>
#include <conio.h>
#endif

#include "win32/serial.h"
#endif
/////// end of Windows specific include files

#if _MSC_VER >= 1400    
// compiler Visual C++ V4.0 -> _MSC_VER >= 1000 
// compiler Visual C++ V4.1 -> _MSC_VER >= 1010
// compiler Visual C++ V5.0 or later -> _MSC_VER >= 1100 
// compiler Visual C++ V6.0 or later -> _MSC_VER >= 1200 
// compiler Visual C++ .NET 2002 -> _MSC_VER = 1300 (version 13, no point release) #VC7.0
// compiler Visual C++ .NET 2003 -> _MSC_VER = 1310 (version 13, release 1.0) #VC7.1
// compiler Visual C++ .NET 2005 -> _MSC_VER = 1400 (version 14, release 0.0) # VC8
#pragma warning(disable : 4996)
#endif

//#include "rtdev.h"

#define ABORT_K		'Q' /* Q to abort */
#define TIME_K		'T' /* T to display current time */
#define CHGTAPE_K	'F' /* F to change image file for a unit */
#define ESCAPE		0x1b

// potential error return values
#define OPEN_ERR  1     // file access, open and read/write
#define READ_ERR  2     // file read error
#define WRITE_ERR 3     // file write error
#define ALLOC_ERR 4     // dynamic allocation
#define RANGE_ERR 5     // index out of range, typically array size or record # exceeds data base size

#define LOOKUP_ERR 6    // can not find in lookup table
#define NO_MEMO_FILE 7  // memo file not available for data base
#define KEY_REPEATED 8  // duplicate key in unique index file
// end off Will's werrcode.h

/* note READ WRITE and POSITION can be effected modifier field in command

   Setting MSB ie | 0x80 selects special address mode with
   128 byte rather than standard 512 byte block size
   In normal mode the valid block # range 0-511, in special mode
   its 0-2047 and zero fill and seek used a 128 block size.

   Setting bit 0 ie | 0x01 during a read increases the read threshold.
   If a tape can be read without errors in this mode it is healthy 
   (has a strong signal).
   
   Setting bit 0 ie | 0x01 during a write operation causes each block
   to be verified via a read with increaded threshold.  The tape repositions
   reads the data just written and verifies the checksum.

   Setting bit 4 of Switches byte during a read forces maintenance mode.
   In this mode there are no retries on a data error, there data
   for a weak block is transmitted as read followed by an end packet
   with a hard data error
*/

/* global variables */
int VerboseMode = 0;
int MrspEnable = 0;
FILE *logf = NULL; 
int TU58Delay = 0; // delay in milliseconds for slow device emulation

int LastFlag = 0;
char XoffReceived = 0;

// INIT_CMD sets/resets bits in Switches
// double INIT clears all bits in Switches
// The Switches register is used only in the MRSP enabled units,
// it is probably write only for the PDP11 (The XXDP ZTUUF0 test progam does not read the bits Switches)
unsigned char Switches = 0;
// function
// bit 0 ???
// bit 1 ??? 
// bit 2 ??? nonstandard XRSP protocol on/off (according http://www.slowdeath.com/AK6DN/PDP-11/TU58/tu58em/index.html)
// bit 3 MRSP protocol on/off
// bit 4 Maintenance moode on/off
// bit 5 ???
// bit 6 ???
// bit 7 ???

unsigned char data[BLOCK_SIZE]; /* global data packet */

unsigned char command[10];      // command packet size
RSP_CMD *cmd = (RSP_CMD *) command;

int fp[2] = {EOF, EOF}; /* file io channels for units from cmd line */

#ifdef _DOS
typedef int* HANDLE;
#endif
HANDLE hTu58Port;       // can be int or something else for other ports

#include "dump.c"

int Tu58Putc(HANDLE hTu58Port, char h)
{
	int x;
	char ready;

	ready = 0;

	SerialPutc(hTu58Port, h);

	if(MrspEnable != 0 && (Switches & MRSP_SWITCH ))
	{
		do{
			x = SerialGetc(hTu58Port);
	
			if(x == CONTINUE) ready= 1;

			printf("%d", x);
		} while(ready == 0);
		printf("\n");
	}

	return 0;
}

void WaitMilliseconds(int delay)
{
// Delays are OS and compiler specific!!
// Delays can be implemented for each port
// If not implemented delay is always 0 ms
#if	_MSC_VER > 1000
	if(delay == 0) return;
	Sleep((DWORD) delay);
#endif

#ifdef _DOS
	clock_t counter;
	if(delay == 0) return;
	counter = clock() + delay;
	while(clock() > counter) return;
#endif
}

unsigned short CalculateChecksum(unsigned char Flag, unsigned char NumBytes, unsigned char *DataBytes)
{
	unsigned char i;
	unsigned long Checksum;

	Checksum = Flag;
	Checksum += 256L * NumBytes;

	for(i = 0; i < NumBytes; i++) {
		if((i % 2) == 0) {					// even index
			Checksum += DataBytes[i];
		} else {							// odd index
			Checksum += 256L * DataBytes[i]; // This is probably big and little endian compatible
		}
		// This is probably big and little endian compatible
	    if(Checksum >= 65536) Checksum = Checksum % 65536 + 1; /* end around carry, WORDSIZE = 0x10000 */
	}

	return (unsigned short) Checksum;
}

int rsp_get_packet(unsigned char *MessageByteCount, unsigned char *DataBytes)
{
    unsigned char i;
	int Flag, suc;
    unsigned int Checksum;

    *MessageByteCount = 0;

	Flag = SerialGetc(hTu58Port);

	if(Flag == XOFF) XoffReceived = 1;
	if(Flag == CONTINUE) XoffReceived = 0;
	if(Flag == XON) XoffReceived = 0;
	if(Flag == INIT) XoffReceived = 0;

	switch(Flag) {
		case BOOT:
			*MessageByteCount = SerialGetc(hTu58Port);  // len set to drive #
			break;
		case DATA:
		case CONTROL:
			suc = SerialGetc(hTu58Port);
			if(suc < 0)	{
				return suc;
			}

			*MessageByteCount = suc;

			for(i = 0; i < *MessageByteCount && i < BLOCK_SIZE; i++) {
				suc = SerialGetc(hTu58Port);

				if(suc >= 0){
					DataBytes[i] = suc;
				} else {
					return suc;
				}
			}

			// get Checksum from host
			suc = SerialGetc(hTu58Port);
			if(suc < 0)	{
				return suc;
			}
			Checksum = suc;

			suc = SerialGetc(hTu58Port);
			if(suc < 0)	{
				return suc;
			}

			Checksum += 256L * suc; // This is probably big and little endian compatible

			if (Checksum != CalculateChecksum(Flag, *MessageByteCount, DataBytes)) {
				if(VerboseMode) printf("Checksum error in rsp_get_packet()!\n");
				return BAD_CHECK;
			}
			break;
	}

	return Flag; /* just return it, now may be BREAK */
} 

// send arbitrary packet with length bytes size effect, clears byte at cnt+1 is cnt is odd
int rsp_snd_packet(unsigned char type,    // INIT for End packet, CONTROL for command packet
				   unsigned char cnt,     // number of bytes of data
				   unsigned char *data)
{
    unsigned char i;
	int suc = OK;
    unsigned short Checksum;

	if(Tu58Putc(hTu58Port, type)) suc = TIMEOUT;
	if(Tu58Putc(hTu58Port, cnt))  suc = TIMEOUT;

	for(i = 0; suc == OK && i < cnt; i++)
    {
         suc = Tu58Putc(hTu58Port, data[i]);
		 if(suc == TIMEOUT) return TIMEOUT;
	}

	Checksum = CalculateChecksum((int) type, (int) cnt, data);

	/* send cksum as word, ie two low order bytes */
	if(suc = Tu58Putc(hTu58Port, (unsigned char) (Checksum % 256)) == TIMEOUT) return suc;
	if(suc = Tu58Putc(hTu58Port, (unsigned char) (Checksum / 256)) == TIMEOUT) return suc;

    return suc;
}

/* special case, ignore RSP and stream 512 bytes of boot sector, block 0 */
int rsp_snd_boot(unsigned char unit)
{
    int i, j, suc = OK;

    if(lseek(fp[unit], 0L, SEEK_SET) != 0L) suc = 1;

    for(i = 0; suc == 0 && i < 4; i++)
    {
         if(read(fp[unit], data, BLOCK_SIZE) != BLOCK_SIZE)
              suc = 2;
         for(j = 0; j < BLOCK_SIZE && suc == 0; j++)
              suc = Tu58Putc(hTu58Port, data[j]);
    }
    return(suc);
}


// process command packets, caller must set up fp if EOF will send NO_TAPE as end packet
int rsp_process_cmd(int fp)
{
    int suc, flag, dot_cnt = 0;
	unsigned char bytes;
    unsigned short SummaryStatus = 0; // set to summary word at end of end packet, new 8/04
    unsigned long offset;
    unsigned short count;

	suc = 0;

	offset = (unsigned long) cmd->block;
	count = (unsigned int) cmd->count;

    if(cmd->modifier & 0x80) // special address mode
	{
       offset = offset * 128; // mini block size
	} else {
       offset = offset * 512; // std block size
	}


	switch(cmd->opcode)
	{
	case POSITION_CMD:
		if(fp == EOF) {
			suc = NO_TAPE; // empty cartridge only error for above
			break;
		}

		// always seek to block
		if(lseek(fp, offset, SEEK_SET) != offset)
		{
			suc = BAD_BLOCK;
            SummaryStatus = 0x2000; // set motion error bit
		}

		if(TU58Delay > 0) WaitMilliseconds(TU58Delay); // delay for slow device emulation

		break;

	case READ_CMD:
		dot_cnt = 0; // for debug
        // seek and read # of blocks requested
		if(lseek(fp, offset, SEEK_SET) != offset)
        {
			suc = BAD_BLOCK;
			SummaryStatus = 0x2000; // set motion error bit
		}
		if(VerboseMode > 1) printf("READ");

		while(count > 0 && suc == OK)
		{
			if(VerboseMode > 1)
			{
				putchar('.');
				if(++dot_cnt >= 64)
				{
					putchar('\n');
					dot_cnt = 0;
				}
			}

			if(count > BLOCK_SIZE)
			{
				bytes = BLOCK_SIZE;
			} else {
				bytes = (unsigned char) count;
			}

			count -= bytes;

			if(read(fp, data, bytes) != bytes)
			{
				suc = FAIL;
				if(VerboseMode > 1) printf("  read err\n");
			}
			else if(rsp_snd_packet(DATA, bytes, data))
			{
				if(VerboseMode > 1) printf("  send err\n");
				suc = FAIL;
				SummaryStatus = 0x1000; // a logic error?
			}
			else if (TU58Delay > 0) WaitMilliseconds(TU58Delay); // delay for slow device emulation
		}
		break;

	case WRITE_CMD:
		// seek and write # of blocks requested
		if(lseek(fp, offset, SEEK_SET) != offset)
        {
			suc = BAD_BLOCK;
			SummaryStatus = 0x2000; // set motion error bit
		}
		if(VerboseMode > 1) printf("WRITE");

		while(count > 0 && suc == OK)
		{
			if(VerboseMode > 1)
			{
				putchar('.');
				if(++dot_cnt >= 64)
				{
					putchar('\n');
					dot_cnt = 0;
				}
			}

			Tu58Putc(hTu58Port, CONTINUE);

			// The following do loop is required for xxdp compatibility.
			// Function wait for a data patket (get rid of CONTINUE and XOFF packets)

			do 
			{
				flag = rsp_get_packet(&bytes, data); 
				if(flag == INIT && LastFlag == INIT) {
					LastFlag = 0;
					SerialClearRxBuffer(hTu58Port);
					return 0;
				}

				LastFlag = flag;
			} while(flag != DATA);


			count -= bytes;

			if(bytes < BLOCK_SIZE) 
			{
				memset(&data[bytes], 0, BLOCK_SIZE - bytes);  // zero fill the unused part of the array if the number of bytes < BLOCK_SIZE
			}


			if(write(fp, data, bytes) != bytes)
            {
					if(VerboseMode > 1) printf("  write err\n");
                    suc = FAIL;
			}
		}
		// goto send end packet
    	break;

	case GETCHAR_CMD:  // 8/22/04 toggle MRSP
		if(VerboseMode > 1)
        {
			if(MrspEnable) 
			{
				printf("GETCHAR_CMD Switches: %x\n", Switches);
			} else {
				printf("GETCHAR_CMD -> RSP only drive\n");
			}
		}

		if(MrspEnable == 0) { // Drives without MRSP capability send a DATA packet
//      memset(data, 0, 24);   // not necessary !!
		rsp_snd_packet(DATA, 24, data);
		return OK;
		}
		// MRSP capable drives send an End Packet
		break;

	// treat all these the same, just an end packet request
	case INIT_CMD:      // reset & send end packet 
		if(MrspEnable != 0) Switches = cmd->switches;
		SerialClearRxBuffer(hTu58Port);
	case NOP_CMD:       // request end packet
	case GETSTATUS_CMD:     // get status, sends end packet
	case SETSTATUS_CMD:     // set status, sends end packet
		break;
	case DIAGNOSE_CMD:  // run internal diagnostice and send end packet 
		break;
	default:
		suc = BAD_OPCODE;
		break;
	}

	// now send an end packet
	cmd->opcode = END_CMD;
    cmd->modifier = suc;
    cmd->sequence = 0;
	cmd->block = 0;

	if(suc != 0) cmd->block = SummaryStatus | 0x8000; // always set special condition bit

	rsp_snd_packet(CONTROL, sizeof(RSP_CMD), (unsigned char *)cmd);

    if(VerboseMode > 1) printf("\nEND PACKET suc = %x summary byte %x\n", cmd->modifier, cmd->block);

	return(suc);
}

void usage(void)
{
   printf("\nusage:\n");
   printf("tu58 [-r|-c]<unit1> [[-r|-c]<unit2>] [-bBaudRate] [-lfnm] [-m] [-d#] [-pPortName] [-t#] [-v#]\n");
   printf("   <unit#> is a file name for tape simulation\n");
   printf("   use invalid name for no file in unit#\n");
   printf("   -b# baudrate\n");
   printf("   -c ahead of file name creates and initializes a TU58 file system\n");
   printf("   -l to open a debug output file, fnm\n");
   printf("   -m enable MRSP support\n");
   printf("   -d# for delay of # milliseconds between reads for slow device emulation\n");
   printf("   -pPortName, e.g., Com2\n");
   printf("   -r ahead of file name opens as read only\n");
   printf("   -t# display timeout message if idle for more than # seconds\n");
   printf("   -v# verbose -> show detailed messages (if # > 0)\n");
   printf("\n   Note at least one valid image file must appear on command line!\n");
   exit(1);
}

int CreateRawImageFile(char *FileName)
{
	long i;
	int fp;
	unsigned char b;

	b = 0xff;

	fp = open(FileName, O_BINARY | O_RDWR | O_CREAT, S_IREAD | S_IWRITE);

	for(i = 0; i < 262144L; i++)
	{
		if( write(fp, &b, 1) == -1) {
			printf("\nError creating image file: %c !\n", FileName);
			return -1;
		}
	}

	close(fp);

	return OK;
}

main(int argc, char *argv[])
{
    time_t t,lt;
    int key, i, line = 1, ret, tsec = -1;
	unsigned char len;
	int BreakReceived = 0;
	int Flag;
	int TypeOfOperation = 0;
	unsigned char unit = 0; // current unit

    unsigned char *fn;
    // following for display of COM status
    char buf[50];
	char PortName[64] = {"Com1"};
	unsigned long BaudRate = 38400; // Factory setting for TU58!

    printf("\nTU58 DECtape II emulator\n");
    printf("Version 2.00\n");

    for(i=1; i < argc; i++)
    {
       if(strnicmp(argv[i],"-r",2) == 0)
       {
           TypeOfOperation = O_RDONLY; // read only
           fn = argv[i]+2;
       }
       else if(strnicmp(argv[i],"-c",2) == 0)
       {
           TypeOfOperation = O_RDWR | O_CREAT;
           fn = argv[i] + 2;
       }
       else
       {
           fn = argv[i];
           TypeOfOperation = O_RDWR; // default is read write
       }

       if(strnicmp(argv[i],"-d",2) == 0)
       {
           ret = atoi(argv[i]+2);
           if(ret > 0)
           {
              TU58Delay = ret;
           }
       }
       if(strnicmp(argv[i],"-v",2) == 0)
           VerboseMode = atoi(argv[i]+2);
	   else if(strnicmp(argv[i],"-m",2) == 0)
           MrspEnable = 1;
       else if(strnicmp(argv[i],"-b",2) == 0)
           BaudRate = atol(argv[i]+2);
       else if(strnicmp(argv[i],"-t",2) == 0)
           tsec = atoi(argv[i]+2); // set timeout
       else if(strnicmp(argv[i],"-p",2) == 0)
           strcpy(PortName, argv[i]+2); // set PortName
       else if(strnicmp(argv[i],"-h",2) == 0)
           usage();
       else if(strnicmp(argv[i],"-i",2) == 0)
           BreakReceived = 1;
       else if(strnicmp(argv[i],"-l",2) == 0 && logf == NULL)
       {
           logf = fopen(argv[i]+2,"a");
           if(logf != NULL)
              printf("\nOpened log file: %s",argv[i]+2);
       }
       else if(i <= 2)
       {                         
		   if(TypeOfOperation & O_CREAT) 
		   {
			   // create unformatted disk image, then open read/write
			   // under RT11 it must be initialized using the "initialize" command
			   if(CreateRawImageFile(fn) == OK) TypeOfOperation = O_RDWR;
		   }
           fp[i - 1] = open(fn, O_BINARY | TypeOfOperation, S_IREAD | S_IWRITE);
		   if(fp[i - 1] == EOF) {
               printf("\nFailed to open unit 0 as %s !\n\n",argv[i]);
			   exit(1);
		   }

       }
    }

    if(argc < 2 || (fp[0] == EOF && fp[1] == EOF))
       usage();
    
    hTu58Port = SerialInit(	PortName, 
							BaudRate,
							8,					// 8 databits
							1,					// 1 stopbit
							'N',				// N -> no parity, E -> even, O -> odd parity
							'N',				// N -> NOPROTOCOL, R -> RTS/CTS, D -> DTR/DSR, X -> XON/XOFF
							1000,				// Rx timeout in milliseconds
							500,				// Tx timeout in milliseconds
//							2 * BLOCK_SIZE,	// Rx buffer size
//							2 * BLOCK_SIZE);	// Tx buffer size
							10,	// Rx buffer size
							10); // Tx buffer size

	if(hTu58Port == NULL) 
	{
		printf("\nError opening Serial port %s !\n", PortName);
		exit(1);
	} else {
		printf("\nSerial port name: %s, Baudrate: %li, 8 databits, no parity, 1 stop bit\n", PortName, BaudRate);
	}

	if(MrspEnable) {
		printf("\nTU58 MRSP support enabled\n");
	} else {
		printf("\nTU58 MRSP support disabled\n");
	}

	if(TU58Delay > 0)
	{
		printf("TU58 read pause = %d milliseconds\n", TU58Delay);
	}

	ret = 0;
    if(fp[0] != EOF) ret++;
    if(fp[1] != EOF) ret++;

    printf("\n%d Units installed:\n", ret);

	for(i = 0; i < ret; i++) 
         printf("   Unit %d: %s\n", i, argv[i + 1]);

    time(&lt);  // init last time to current time

    // loop until get ABORT_K
	printf("\nWaiting for command packets.  'Q' or <ESCAPE> to terminate 'T' prints time\n");

    while(1) 
    {       
       if(kbhit())
       {
          key = getch();
          key = toupper(key);
          if(key == ABORT_K || key == ESCAPE)
			  break;
          else if(key == TIME_K)
          {
              time(&t);
              printf("\n%s",ctime(&t));
          }
          else if(key == CHGTAPE_K)
          {
              do 
                 printf("\nChange tape in Unit (0/1): ");
              while((key = getch()) != '0' && key != '1');
              do {
                 printf("\nfile type (C => Create New, R => Read only, W => Read/Write):");
                 i = getch();
                 i = toupper(i);
              } while(i != 'C' && i != 'R' && i != 'W');
              printf("\nNew file name, or none for no tape: ");
              fgets(buf, 40, stdin);
              TypeOfOperation = O_RDWR; /* default is read write */
              if(i == 'C')
              {
                  // create unformatted disk image, then open read/write
				  // under RT11 it must be initialized using the "initialize" command
				  if(CreateRawImageFile(fn) == OK) TypeOfOperation = O_CREAT;
              }
              else if (i == 'R')
				  TypeOfOperation = O_RDONLY; /* read only */
              i = strlen(buf);
              if(i > 0 && buf[i-1] == '\n')
				  buf[i-1] = 0;
              i = open(buf, O_BINARY | TypeOfOperation, S_IREAD | S_IWRITE);
              if(i == EOF)
              {
                 if(strlen(buf) > 0)
                    printf("\nfailed to open unit file %s", buf);
                 printf("\nUnit %c will be treated as an empty slot", key);
              }
              if(key == '1')
              {
                 if(fp[1] != EOF)
                     close(fp[1]);
                 fp[1] = i;
              }
              else
              {
                 if(fp[0] != EOF)
                     close(fp[0]);
                 fp[0] = i;
              }
          }
       }

        Flag = rsp_get_packet(&len, data);

        if(i == 1 ) Flag = TIMEOUT;

		if(VerboseMode > 0) {
			switch(Flag)
			{
				case DATA:			printf("Command received -> DATA   \n"); break;
				case CONTROL:		printf("Command received -> CONTROL\n"); break;
				case INIT:			printf("Command received -> INIT \n"); break;
				case BOOT:			printf("Command received -> BOOT \n"); break;
				case CONTINUE:      printf("Command received -> CONTINUE \n"); break;
				case XON:			printf("Command received -> XON   \n"); break;
				case XOFF:			printf("Command received -> XOFF  \n"); break;
				case BREAK:			printf("Command received -> BREAK \n"); break;
				case TIMEOUT: break;
				case 0: break;
				default:            printf("Command received -> Error Flag= %x\n", Flag); break;
	        }
		}

	   // process commands
		switch(Flag)
		{
			case TIMEOUT:
				if(BreakReceived == 0) Tu58Putc(hTu58Port, INIT);
				break;
            case BREAK:
			case 0: // nulls are probably BREAKs
				BreakReceived = 1;
				break;
			case BOOT:
				if(len == 0 || len == 1)
				{
					rsp_snd_boot(len);
					if(VerboseMode) printf("Booting unit %d\n", len);
				} else {
					printf("BOOT error, non existing unit %d\n", len);
					if(logf != NULL)
					{
						if(fp[len] == EOF) fprintf(logf,"\nBOOT error, non existing unit %d", len);
					} else {
						fprintf(logf,"\nBoot error, non existing unit %d", len);
					}
				}
				break;
			case INIT: // just send the continue
				if(LastFlag == INIT) // two INITs in a row ?
				{
					Switches = 0; // Clear bits in Switches, e.g,  MRSP off
					SerialClearRxBuffer(hTu58Port);
//					WaitMilliseconds(100);
					Tu58Putc(hTu58Port, CONTINUE);
					if(VerboseMode) printf("CONTINUE after 2 INIT flags\n");
					if(logf != NULL) fprintf(logf,"\nCONTINUE after 2 INIT flags");
					Flag = -1; // clear INIT LastFlag below
				}
				break;
			case DATA:
				printf("\ndata packet out of sequence");
				SerialClearRxBuffer(hTu58Port);
				Tu58Putc(hTu58Port, INIT);
				Tu58Putc(hTu58Port, INIT);
				Flag = 0; // force resync
				break;
			case CONTROL:
				cmd = (RSP_CMD *) data;
				if(VerboseMode > 0) {
					switch(cmd->opcode)
					{
						case NOP_CMD:       printf("Nop  "); break;
						case INIT_CMD:      printf("Init "); break;
						case READ_CMD:      printf("Read "); break;
						case WRITE_CMD:     printf("Write "); break;
						case POSITION_CMD:  printf("Seek "); break;         
						case DIAGNOSE_CMD:  printf("Diag "); break;
						case GETSTATUS_CMD: printf("Getstatus "); break;
						case SETSTATUS_CMD: printf("Setstatus "); break;
						case GETCHAR_CMD:   printf("Getchar   "); break;
					}
				}

				if(VerboseMode) printf("count %d DEC block %d DEC\n", cmd->count,cmd->block);
				if(logf != NULL)
				{
					fprintf(logf,"\nopcode %d DEC count %d DEC block %d DEC", cmd->opcode, cmd->count, cmd->block);
					if(VerboseMode)
					{
						fputc('\n',logf);
						dump(logf, data, len, line++);
					}
				}
				if(cmd->unit == 0 || cmd->unit == 1)
					rsp_process_cmd(fp[cmd->unit]);
				else
					printf("invalid unit # %d in command\n", cmd->unit);
				break;
			case BAD_CHECK:
					SerialClearRxBuffer(hTu58Port);
//					WaitMilliseconds(100);
					if(VerboseMode) printf("CONTINUE after checksum error\n");
					Flag = -1; // clear INIT LastFlag below
				break;
			case XOFF:
				break;
			default:
//				if(VerboseMode) printf("Unknown Flag received ! Flag = 0x%X Dec %i\n" , Flag, Flag);
				break;
		}
		LastFlag = Flag;

		if(Flag != TIMEOUT) {
			time(&lt);  // set last time to current time
		} else {
			if(tsec > 0 && lt > 0)  // watch for 1st timeout
			{
				time(&t);
				if(t -lt > tsec)
				{
					lt = 0; // clear lt so only print once
					printf("%sSystem idle for more than %d seconds, press 'Q' or <ESCAPE> to exit\n", ctime(&t), tsec);
				}
			}
		}
    }

	SerialClose(hTu58Port);

    if(fp[0] != EOF) close(fp[0]);

    if(fp[1] != EOF) close(fp[1]);

    if(logf != NULL) fclose(logf);

    return 0;
}
// end of main




